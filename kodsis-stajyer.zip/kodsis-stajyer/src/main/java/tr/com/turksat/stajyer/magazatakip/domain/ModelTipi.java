package tr.com.turksat.stajyer.magazatakip.domain;

/**
 * Created by husnu on 9.7.2015.
 */
public class ModelTipi
{
    private String modeltipi;

    public ModelTipi()
    {

    }
    public String getMoldeltipi() {
        return modeltipi;
    }
    public void setModeltip(String modeltipi) {
        this.modeltipi = modeltipi;
    }


}
