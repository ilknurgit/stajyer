package tr.com.turksat.stajyer.magazatakip.domain;

/**
 * Created by husnu on 10.7.2015.
 */
public class MarkaTipi {
    private String markatipi;
    public MarkaTipi()
    {

    }

    public String getMarkatipi() {
        return markatipi;
    }
    public void setMarkatipi(String markatipi) {
        this.markatipi = markatipi;
    }
}
